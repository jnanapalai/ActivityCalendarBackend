package com.activity.activitycalendar.entity;

public enum ActivityStatus {
    ASSIGNED,
    FINISHED
}
