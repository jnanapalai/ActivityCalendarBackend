package com.activity.activitycalendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivityCalendarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActivityCalendarApplication.class, args);
	}

}
